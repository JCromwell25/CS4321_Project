package sms;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ChooseStore {

    private JFrame frmChooseAStore;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ChooseStore window = new ChooseStore();
                    window.frmChooseAStore.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public ChooseStore() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frmChooseAStore = new JFrame();
        frmChooseAStore.setAlwaysOnTop(true);
        frmChooseAStore.setResizable(false);
        frmChooseAStore.setTitle("FUNCTIONALITIES");
        frmChooseAStore.setBounds(100, 100, 500, 400);
        frmChooseAStore.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmChooseAStore.getContentPane().setLayout(null);
        
        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 484, 361);
        frmChooseAStore.getContentPane().add(panel);
        panel.setLayout(null);
        
        JLabel header = new JLabel("DIFFERENT FUNCTIONALITIES");
        header.setHorizontalAlignment(SwingConstants.CENTER);
        header.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        header.setBounds(106, 11, 280, 39);
        panel.add(header);
        
        JButton orderBtn = new JButton("ORDER");
        orderBtn.setBounds(73, 82, 313, 39);
        panel.add(orderBtn);

        JButton viewOrderBtn = new JButton("VIEW MY ORDERS");
        viewOrderBtn.setBounds(73, 169, 313, 39);
        panel.add(viewOrderBtn);
        
        JButton exitBtn = new JButton("EXIT");
        exitBtn.setBounds(116, 280, 237, 39);
        panel.add(exitBtn);
        exitBtn.addActionListener(e -> {
            frmChooseAStore.dispose();
            Login.main(null);
        });
        // Action listener for the ORDER button
        orderBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frmChooseAStore.dispose(); // Close the current frame
                new PlaceOrder(); // Open the PlaceOrder frame
            }
        });
        viewOrderBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frmChooseAStore.dispose(); // Close the current frame
                 ViewOrder.main(null); // Open the PlaceOrder frame
            }
        });
    }
}
