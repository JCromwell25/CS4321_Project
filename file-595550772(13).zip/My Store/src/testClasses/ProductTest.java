package testClasses;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
//importing product class
import sms.Product;
public class ProductTest {
    private Product product;

    @BeforeEach
    public void setUp() {
        product = new Product("1", "101", "Test Product", "Test Manufacturer", 10.99, 5, true);
    }

    @Test
    public void testGetStoreId() {
        assertEquals("1", product.getStoreId());
    }

    @Test
    public void testGetId() {
        assertEquals("101", product.getId());
    }

    @Test
    public void testGetName() {
        assertEquals("Test Product", product.getName());
    }

    @Test
    public void testGetManufacturer() {
        assertEquals("Test Manufacturer", product.getManufacturer());
    }

    @Test
    public void testGetPrice() {
        assertEquals(10.99, product.getPrice());
    }

    @Test
    public void testGetQuantity() {
        assertEquals(5, product.getQuantity());
    }

    @Test
    public void testIsFood() {
        assertTrue(product.isFood());
    }

    @Test
    public void testToString() {
        assertEquals("1,101,Test Product,Test Manufacturer,10.99,5,Yes", product.toString());
    }
}