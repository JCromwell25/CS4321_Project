package testClasses;

import sms.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.swing.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class OrderManagerTest {

    private OrderManager orderManager;
    private JComboBox<String> productCombo;

    @BeforeEach
    void setUp() {
        orderManager = new OrderManager();
        productCombo = new JComboBox<>();
        createTestProductFile(); // Create a test products file
    }

    private void createTestProductFile() {
        try (FileWriter writer = new FileWriter("products_TEST.txt")) {
            writer.write("1,1,Apple,Fruit,1.00,400,true\n");
            writer.write("1,2,Shampoo,Hair Care,500,300,false\n");
            writer.write("2,3,Banana,Fruit,0.50,200,true\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    void testPopulateProductNames() {
        orderManager.populateProductNames("1", productCombo);
        assertEquals(2, productCombo.getItemCount(), "Should have 2 products for store ID 1");
        assertEquals("Apple", productCombo.getItemAt(0));
        assertEquals("Shampoo", productCombo.getItemAt(1));
    }

    @Test
    void testGetProductPrice() {
        orderManager.populateProductNames("1", productCombo);
        String price = orderManager.getProductPrice("Apple");
        assertEquals("1.00", price, "Price of Apple should be 1.00");
    }

    @Test
    void testCalculateTaxForFood() {
        double subtotal = 10.00;
        double tax = orderManager.calculateTax("Apple", subtotal);
        assertEquals(0.40, tax, "Tax for food (4%) should be 0.40");
    }

    @Test
    void testCalculateTaxForNonFood() {
        double subtotal = 10.00;
        double tax = orderManager.calculateTax("Shampoo", subtotal);
        assertEquals(0.80, tax, "Tax for non-food (8%) should be 0.80");
    }

    @Test
    void testGenerateOrderId() {
        String orderId = orderManager.generateOrderId();
        assertNotNull(orderId, "Order ID should not be null");
        assertEquals(6, orderId.length(), "Order ID should be 6 digits long");
    }

    @Test
    void testSaveOrderToFile() {
        String orderId = "123456";
        String customerID = "C001";
        String cartContents = "Apple x 2\nShampoo x 1\n";
        double totalCost = 12.80; // 2 * 1.00 + 1 * 5.00 + tax (0.40 + 0.80)

        orderManager.saveOrderToFile(orderId, customerID, cartContents, totalCost);

        // Verify if the order was saved correctly
        File ordersFile = new File("orders_TEST.txt");
        assertTrue(ordersFile.exists(), "Orders file should exist");
        // You can add more checks here to verify the content of the file if needed
    }
}