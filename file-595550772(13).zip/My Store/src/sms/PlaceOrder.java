package sms;

import javax.swing.*;
import java.awt.*;
import java.awt.print.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PlaceOrder {
    private JFrame frmPlaceAndOrder;
    private JTextField priceField;
    private JTextField quantityField;
    private JTextArea cartArea;
    private JTextArea receiptArea;
    private JComboBox<String> pNameCombo;
    private JComboBox<String> storeNameCombo;
    private JTextField cIdField;
    private OrderManager orderManager;

    public PlaceOrder() {
        orderManager = new OrderManager(); // Initialize OrderManager
        initialize();
        frmPlaceAndOrder.setVisible(true);
    }

    private void initialize() {
        frmPlaceAndOrder = new JFrame();
        frmPlaceAndOrder.setResizable(false);
        frmPlaceAndOrder.setTitle("PLACE AND ORDER");
        frmPlaceAndOrder.setBounds(100, 100, 600, 450);
        frmPlaceAndOrder.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmPlaceAndOrder.getContentPane().setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 584, 411);
        frmPlaceAndOrder.getContentPane().add(panel);
        panel.setLayout(null);

        JLabel lblTitle = new JLabel("ORDER TAB");
        lblTitle.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setBounds(169, 11, 205, 33);
        panel.add(lblTitle);

        JLabel lblStoreName = new JLabel("STORE NAME");
        lblStoreName.setHorizontalAlignment(SwingConstants.CENTER);
        lblStoreName.setBounds(10, 61, 151, 33);
        panel.add(lblStoreName);

        JLabel lblProductName = new JLabel("PRODUCT NAME");
        lblProductName.setHorizontalAlignment(SwingConstants.CENTER);
        lblProductName.setBounds(10, 131, 120, 27);
        panel.add(lblProductName);

        pNameCombo = new JComboBox<>();
        pNameCombo.setBounds(140, 128, 162, 33);
        panel.add(pNameCombo);

        storeNameCombo = new JComboBox<>();
        storeNameCombo.setBounds(140, 61, 167, 33);
        panel.add(storeNameCombo);
        
        populateStoreNames(); // Populate store names

        JLabel lblPrice = new JLabel("PRICE");
        lblPrice.setBounds(313, 131, 46, 27);
        panel.add(lblPrice);

        priceField = new JTextField();
        priceField.setBackground(Color.LIGHT_GRAY);
        priceField.setEditable(false);
        priceField.setBounds(379, 128, 195, 30);
        panel.add(priceField);
        priceField.setColumns(10);

        JLabel lblQuantity = new JLabel("QUANTITY");
        lblQuantity.setHorizontalAlignment(SwingConstants.CENTER);
        lblQuantity.setBounds(10, 180, 120, 27);
        panel.add(lblQuantity);

        quantityField = new JTextField();
        quantityField.setBounds(140, 172, 162, 31);
        panel.add(quantityField);
        quantityField.setColumns(10);

        JButton addCartBtn = new JButton("ADD TO CART");
        addCartBtn.setBounds(323, 169, 112, 33);
        panel.add(addCartBtn);

        JButton placeOrderBtn = new JButton("PLACE ORDER");
        placeOrderBtn.setBounds(446, 169, 128, 33);
        panel.add(placeOrderBtn);

        cartArea = new JTextArea();
        cartArea.setBackground(Color.LIGHT_GRAY);
        cartArea.setBounds(41, 239, 205, 161);
        panel.add(cartArea);

        receiptArea = new JTextArea();
        receiptArea.setBackground(Color.GRAY);
        receiptArea.setBounds(284, 239, 195, 161);
        panel.add(receiptArea);

        JLabel lblCartDisplay = new JLabel("CART DISPLAY");
        lblCartDisplay.setBounds(72, 218, 128, 14);
        panel.add(lblCartDisplay);

        JLabel lblReceiptArea = new JLabel("RECEIPT AREA");
        lblReceiptArea.setBounds(333, 218, 102, 14);
        panel.add(lblReceiptArea);

        JButton exitBtn = new JButton("EXIT");
        exitBtn.setBounds(489, 294, 85, 33);
        panel.add(exitBtn);
        
        JLabel lblCustomerId = new JLabel("CUSTOMER ID");
        lblCustomerId.setBounds(323, 61, 81, 33);
        panel.add(lblCustomerId);
        
        cIdField = new JTextField();
        cIdField.setBackground(Color.LIGHT_GRAY);
        cIdField.setBounds(414, 61, 128, 33);
        panel.add(cIdField);
        cIdField.setColumns(10);

        // Action listener for store selection
        storeNameCombo.addActionListener(e -> {
            String selectedStore = (String) storeNameCombo.getSelectedItem();
            if (selectedStore != null) {
                String storeId = selectedStore.split(",")[0].trim(); // Extract store ID
                orderManager.populateProductNames(storeId, pNameCombo); // Populate products based on selected store
            }
        });

        // Action listener for Add to Cart button
        addCartBtn.addActionListener(e -> {
            String productName = (String) pNameCombo.getSelectedItem();
            String quantityText = quantityField.getText();

            if (productName != null && !quantityText.isEmpty()) {
                try {
                    int quantity = Integer.parseInt(quantityText);
                    if (quantity <= 0) throw new NumberFormatException();
                    cartArea.append(productName + " x " + quantity + "\n");
                    clearFields();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frmPlaceAndOrder, "Please enter a valid quantity.", "Invalid Input", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        // Action listener for Place Order button
        placeOrderBtn.addActionListener(e -> {
            String cartContents = cartArea.getText();
            String customerID = cIdField.getText();
            String selectedStore = (String) storeNameCombo.getSelectedItem();
            
            if (selectedStore == null || selectedStore.isEmpty()) {
                JOptionPane.showMessageDialog(frmPlaceAndOrder, "Please select a store.", "Store Not Selected", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String storeId = selectedStore.split(",")[0].trim(); // Extract store ID

            if (!cartContents.isEmpty()) {
                double totalCost = 0.0; // Variable to store total cost
                StringBuilder receiptDetails = new StringBuilder("RECEIPT:\n");
                receiptDetails.append("Store Name: ").append(selectedStore).append("\n");
                receiptDetails.append("Store ID: ").append(storeId).append("\n");
                receiptDetails.append("Date: ").append(new SimpleDateFormat("MM/dd/yyyy").format(new Date())).append("\n\n");
                receiptDetails.append("Items:\n");

                // Calculate total cost based on cart contents
                for (String line : cartContents.split("\n")) {
                    String[] parts = line.split(" x ");
                    if (parts.length == 2) {
                        String productName = parts[0].trim();
                        int quantity = Integer.parseInt(parts[1].trim());

                        // Get price and product type from the productPrices map
                        String priceString = orderManager.getProductPrice(productName);
                        String productType = orderManager.getProductType(productName); // Assuming you have this method
                        
                        if (priceString != null) {
                            double price = Double.parseDouble(priceString);
                            double subtotal = quantity * price;

                            double taxRate = productType.equals("food") ? 0.04 : 0.08; // 4% for food, 8% for non-food
                            double tax = subtotal * taxRate; // Calculate tax
                            double totalItemCost = subtotal + tax; // Total for the item

                            totalCost += totalItemCost; // Update total cost
                            receiptDetails.append(productName).append(" x ").append(quantity)
                                    .append(" - Subtotal: $").append(String.format("%.2f", subtotal))
                                    .append(" - Tax: $").append(String.format("%.2f", tax))
                                    .append(" - Total: $").append(String.format("%.2f", totalItemCost)).append("\n");
                        }
                    }
                }

                receiptDetails.append("\nTotal Cost: $").append(String.format("%.2f", totalCost));
                receiptArea.setText(receiptDetails.toString());

                // Show payment confirmation dialog
                int paymentResult = JOptionPane.showConfirmDialog(frmPlaceAndOrder,
                        "Proceed to payment?\nTotal Cost: $" + String.format("%.2f", totalCost),
                        "Payment Confirmation", JOptionPane.YES_NO_OPTION);

                if (paymentResult == JOptionPane.YES_OPTION) {
                    // Generate a unique order ID and save the order to orders.txt
                    String orderId = orderManager.generateOrderId();
                    orderManager.saveOrderToFile(orderId, customerID, cartContents, totalCost);
                    // Show the receipt preview dialog
                    showReceiptPreview(receiptDetails.toString());
                    clearFields();
                }
            } else {
                JOptionPane.showMessageDialog(frmPlaceAndOrder, "Your cart is empty.", "No Items", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // Action listener for Exit button
        exitBtn.addActionListener(e -> {
        frmPlaceAndOrder.dispose();
        		ChooseStore.main(null);});

        // Action listener for product name selection
        pNameCombo.addActionListener(e -> {
            String selectedProduct = (String) pNameCombo.getSelectedItem();
            if (selectedProduct != null) {
                retrieveProductPrice(selectedProduct); // Retrieve the price when a product is selected
            }
        });
    }

    private void clearFields() {
        quantityField.setText(null);
        priceField.setText(null);
    }

    private void populateStoreNames() {
        try (BufferedReader br = new BufferedReader(new FileReader("store.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                storeNameCombo.addItem(line.trim());
            }
        } catch (IOException e) {
            showErrorDialog("Error loading stores: " + e.getMessage());
        }
    }

    private void retrieveProductPrice(String productName) {
        String price = orderManager.getProductPrice(productName);
        if (price != null) {
            priceField.setText(price);
        } else {
            priceField.setText("N/A"); // Provide feedback if the price is not found
        }
    }

    private void showReceiptPreview(String receiptContent) {
        JDialog previewDialog = new JDialog(frmPlaceAndOrder, "Receipt Preview", true);
        previewDialog.setSize(400, 300);
        previewDialog.setLocationRelativeTo(frmPlaceAndOrder);
        JTextArea previewArea = new JTextArea(receiptContent);
        previewArea.setEditable(false);
        previewArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        previewArea.setLineWrap(true);
        previewArea.setWrapStyleWord(true);
        
        JButton printButton = new JButton("Print Receipt");
        printButton.addActionListener(e -> {
            printReceipt(receiptContent);
            previewDialog.dispose(); // Close the dialog after printing
        });

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> previewDialog.dispose());

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(previewArea), BorderLayout.CENTER);
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(printButton);
        buttonPanel.add(closeButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        previewDialog.getContentPane().add(panel);
        previewDialog.setVisible(true);
    }

    private void printReceipt(String receiptContent) {
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(orderManager); // Set OrderManager as the printable
        boolean doPrint = job.printDialog(); // Show print dialog to the user
        if (doPrint) {
            try {
                job.print(); // Start printing
            } catch (PrinterException e) {
                showErrorDialog("Error during printing: " + e.getMessage());
            }
        }
    }

    private void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(frmPlaceAndOrder, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        new PlaceOrder();
    }
}