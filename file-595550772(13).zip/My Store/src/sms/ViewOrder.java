package sms;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.ArrayList;

public class ViewOrder {

    private JFrame frmViewOrders;
    private JTable table;
    private DefaultTableModel tableModel;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ViewOrder window = new ViewOrder();
                window.frmViewOrders.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public ViewOrder() {
        initialize();
    }

    private void initialize() {
        frmViewOrders = new JFrame();
        frmViewOrders.setTitle("VIEW ORDERS");
        frmViewOrders.setBounds(100, 100, 700, 450);
        frmViewOrders.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmViewOrders.getContentPane().setLayout(null);
        
        JPanel panel = new JPanel();
        panel.setBorder(new LineBorder(new Color(0, 0, 0)));
        panel.setBounds(0, 0, 684, 400);
        frmViewOrders.getContentPane().add(panel);
        panel.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("ORDERS DETAILS");
        lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setBounds(239, 11, 215, 34);
        panel.add(lblNewLabel);

        JButton viewOrdersBtn = new JButton("View Orders");
        viewOrdersBtn.setBounds(31, 56, 120, 30);
        panel.add(viewOrdersBtn);
        
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Order ID");
        tableModel.addColumn("Items");
        tableModel.addColumn("Total Cost");

        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(31, 100, 643, 204);
        panel.add(scrollPane);
        
        JButton exitBtn = new JButton("EXIT");
        exitBtn.setBounds(400, 315, 150, 30);
        panel.add(exitBtn);
        exitBtn.addActionListener(e -> {
            frmViewOrders.dispose();
            ChooseStore.main(null);
        });

        viewOrdersBtn.addActionListener(e -> {
            String customerId = JOptionPane.showInputDialog(frmViewOrders, "Enter Customer ID:");
            if (customerId != null && !customerId.trim().isEmpty()) {
                loadOrderData(customerId.trim());
            } else {
                JOptionPane.showMessageDialog(frmViewOrders, "Please enter a valid Customer ID.", "Input Error", JOptionPane.WARNING_MESSAGE);
            }
        });

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) { // Double-click to select
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) {
                        String orderId = (String) tableModel.getValueAt(selectedRow, 0);
                        String items = (String) tableModel.getValueAt(selectedRow, 1);
                        handleOrderRemoval(orderId, items);
                    }
                }
            }
        });
    }

    private void loadOrderData(String customerId) {
        tableModel.setRowCount(0);
        try (BufferedReader br = new BufferedReader(new FileReader("orders.txt"))) {
            String line;
            String orderId = null, items = "", totalCost = null;

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("Order ID: ")) {
                    if (orderId != null && line.contains(customerId)) {
                        tableModel.addRow(new Object[]{orderId, items.trim(), totalCost});
                    }
                    orderId = line.substring("Order ID: ".length()).trim();
                    items = ""; 
                } else if (line.startsWith("Customer ID: ")) {
                    if (!line.contains(customerId)) {
                        orderId = null;
                    }
                } else if (line.startsWith("Items:")) {
                    continue; 
                } else if (!line.isEmpty() && !line.equals("=================================")) {
                    if (line.startsWith("Total Cost: ")) {
                        totalCost = line.substring("Total Cost: ".length()).trim();
                    } else {
                        items += line + "\n"; 
                    }
                }
            }

            if (orderId != null && items != null && totalCost != null && items.trim().length() > 0) {
                tableModel.addRow(new Object[]{orderId, items.trim(), totalCost});
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleOrderRemoval(String orderId, String items) {
        String[] options = {"Remove Whole Order", "Remove Specific Product", "Cancel"};
        int choice = JOptionPane.showOptionDialog(frmViewOrders, "What would you like to do?", "Select Action",
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[2]);

        if (choice == 0) {
            removeWholeOrder(orderId);
        } else if (choice == 1) {
            String productId = JOptionPane.showInputDialog(frmViewOrders, "Enter Product ID to Remove:");
            if (productId != null && !productId.trim().isEmpty()) {
                removeProductFromOrder(orderId, productId.trim(), items);
            } else {
                JOptionPane.showMessageDialog(frmViewOrders, "Please enter a valid Product ID.", "Input Error", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    private void removeWholeOrder(String orderId) {
        StringBuilder updatedOrders = new StringBuilder();

        try (BufferedReader br = new BufferedReader(new FileReader("orders.txt"))) {
            String line;
            boolean orderFound = false;

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("Order ID: ")) {
                    if (line.contains(orderId)) {
                        orderFound = true;
                        // Skip this order
                        continue;
                    }
                }
                updatedOrders.append(line).append("\n");
            }

            if (orderFound) {
                try (FileWriter writer = new FileWriter("orders.txt")) {
                    writer.write(updatedOrders.toString());
                    JOptionPane.showMessageDialog(frmViewOrders, "Whole order removed successfully.");
                    loadOrderData(""); // Reload to refresh the table
                }
            } else {
                JOptionPane.showMessageDialog(frmViewOrders, "Order not found.", "Error", JOptionPane.WARNING_MESSAGE);
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frmViewOrders, "Error processing removal.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void removeProductFromOrder(String orderId, String productId, String items) {
        boolean productFound = false;
        StringBuilder updatedOrders = new StringBuilder();

        try (BufferedReader br = new BufferedReader(new FileReader("orders.txt"))) {
            String line;
            String totalCost = null;
            double total = 0.0;

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("Order ID: ")) {
                    if (line.contains(orderId)) {
                        productFound = true;
                        items = removeProduct(items, productId);
                    }
                    updatedOrders.append(line).append("\n");
                    updatedOrders.append("Customer ID: ").append("...").append("\n"); // Placeholder for customer ID
                    updatedOrders.append("Items:\n").append(items).append("\n");
                } else if (line.startsWith("Total Cost: ")) {
                    if (productFound) {
                        total = calculateNewTotal(items);
                        updatedOrders.append("Total Cost: $").append(total).append("\n");
                    } else {
                        updatedOrders.append(line).append("\n");
                    }
                } else {
                    updatedOrders.append(line).append("\n");
                }
            }

            if (productFound) {
                try (FileWriter writer = new FileWriter("orders.txt")) {
                    writer.write(updatedOrders.toString());
                    JOptionPane.showMessageDialog(frmViewOrders, "Product removed successfully.");
                    loadOrderData(""); // Reload to refresh the table
                }
            } else {
                JOptionPane.showMessageDialog(frmViewOrders, "Product not found in the selected order.", "Error", JOptionPane.WARNING_MESSAGE);
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frmViewOrders, "Error processing removal.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String removeProduct(String items, String productId) {
        String[] itemLines = items.split("\n");
        StringBuilder updatedItems = new StringBuilder();

        for (String item : itemLines) {
            if (!item.contains(productId)) {
                updatedItems.append(item).append("\n");
            }
        }
        return updatedItems.toString();
    }

    private double calculateNewTotal(String items) {
        double total = 0.0;
        String[] itemLines = items.split("\n");

        for (String item : itemLines) {
            String[] parts = item.split(" x ");
            if (parts.length == 2) {
                int quantity = Integer.parseInt(parts[1].trim());
                double price = getPrice(parts[0].trim());
                total += price * quantity;
            }
        }
        return total;
    }

    private double getPrice(String productName) {
        double price = 0.0;
        try (BufferedReader br = new BufferedReader(new FileReader("products.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts[0].equalsIgnoreCase(productName)) {
                    price = Double.parseDouble(parts[1]);
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return price;
    }
}