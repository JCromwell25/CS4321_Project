package sms;

public class Product {
    private String storeId;
    private String id;
    private String name;
    private String manufacturer;
    private double price;
    private int quantity;
    private boolean isFood;

    public Product(String storeId, String id, String name, String manufacturer, double price, int quantity, boolean isFood) {
        this.storeId = storeId;
        this.id = id;
        this.name = name;
        this.manufacturer = manufacturer;
        this.price = price;
        this.quantity = quantity;
        this.isFood = isFood;
    }

    public String getStoreId() {
        return storeId;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public boolean isFood() {
        return isFood;
    }

    @Override
    public String toString() {
        return storeId + "," + id + "," + name + "," + manufacturer + "," + price + "," + quantity + "," + (isFood ? "Yes" : "No");
    }
}