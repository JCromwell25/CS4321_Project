package sms;

import java.awt.Graphics;
import java.awt.print.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import javax.swing.JComboBox;

public class OrderManager implements Printable {
    private Map<String, String> productPrices; // Store product prices
    private Map<String, Boolean> productIsFood; // Store product type (true for food, false for non-food)
    private final double foodTaxRate = 0.04; // Tax rate for food items
    private final double nonFoodTaxRate = 0.08; // Tax rate for non-food items

    public OrderManager() {
        productPrices = new HashMap<>();
        productIsFood = new HashMap<>();
    }

    public void populateProductNames(String storeId, JComboBox<String> productCombo) {
        productCombo.removeAllItems(); // Clear existing items
        productPrices.clear(); // Clear existing prices
        productIsFood.clear(); // Clear existing product types
        try (BufferedReader br = new BufferedReader(new FileReader("products.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(","); // Assuming CSV format
                if (parts.length > 5 && parts[0].trim().equals(storeId)) { // Check if store ID matches
                    String productName = parts[2].trim();
                    String price = parts[4].trim(); // Assuming price is the 5th column
                    boolean isFood = Boolean.parseBoolean(parts[6].trim()); // Assuming food type is in the 6th column
                    productCombo.addItem(productName); // Add product name to combo box
                    productPrices.put(productName, price); // Store product price in map
                    productIsFood.put(productName, isFood); // Store whether the product is food
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getProductPrice(String productName) {
        return productPrices.get(productName);
    }

    public double calculateTax(String productName, double subtotal) {
        boolean isFood = productIsFood.getOrDefault(productName, false);
        return isFood ? subtotal * foodTaxRate : subtotal * nonFoodTaxRate;
    }

    public String getProductType(String productName) {
        Boolean isFood = productIsFood.get(productName);
        return (isFood != null && isFood) ? "food" : "non-food"; // Return type based on the product
    }

    public String generateOrderId() {
        Random random = new Random();
        return String.format("%06d", random.nextInt(1000000)); // Generate a random 6-digit number
    }

    public void saveOrderToFile(String orderId, String customerID, String cartContents, double totalCost) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("orders.txt", true))) {
            writer.write("Order ID: " + orderId);
            writer.newLine();
            writer.write("Customer ID: " + customerID);
            writer.newLine();
            writer.write("Items:\n" + cartContents);
            writer.write("Total Cost: $" + totalCost);
            writer.newLine();
            writer.write("=================================");
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int print(Graphics g, PageFormat pf, int pageIndex) throws PrinterException {
        // Printing logic goes here
        return PAGE_EXISTS; // Indicate that the page was successfully printed
    }
}