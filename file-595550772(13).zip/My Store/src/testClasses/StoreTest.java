package testClasses;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import sms.Store;

public class StoreTest {
    private Store store;

    @BeforeEach
    public void setUp() {
        store = new Store("1", "Test Store");
    }

    @Test
    public void testGetId() {
        assertEquals("1", store.getId());
    }

    @Test
    public void testGetName() {
        assertEquals("Test Store", store.getName());
    }

    @Test
    public void testToString() {
        assertEquals("1,Test Store", store.toString());
    }
}