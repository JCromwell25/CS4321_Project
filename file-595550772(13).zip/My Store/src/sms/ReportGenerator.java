package sms;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.util.List;
import java.util.stream.Collectors;

public class ReportGenerator {

    private JFrame frame;
    private JTextArea reportArea;
    private JComboBox<String> reportSelection;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ReportGenerator window = new ReportGenerator();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public ReportGenerator() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setTitle("Store Reports");
        frame.setBounds(100, 100, 800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JPanel panel = new JPanel();
        panel.setBorder(new LineBorder(Color.BLACK));
        panel.setBounds(10, 10, 764, 540);
        frame.getContentPane().add(panel);
        panel.setLayout(null);

        JLabel lblTitle = new JLabel("Store Reports");
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 18));
        lblTitle.setBounds(10, 11, 744, 30);
        panel.add(lblTitle);

        // Report selection dropdown
        reportSelection = new JComboBox<>(new String[]{
            "Select Report",
            "Stock Report",
            "Items by Manufacturer",
            "Customer Receipts",
            "Most Popular Products by Quantity",
            "Most Popular Products by Revenue",
            "Product Report",
            "Customer List" // New option added here
        });
        reportSelection.setBounds(10, 52, 200, 30);
        panel.add(reportSelection);

        // Report display area
        reportArea = new JTextArea();
        reportArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(reportArea);
        scrollPane.setBounds(10, 93, 744, 400);
        panel.add(scrollPane);

        // Generate button
        JButton btnGenerate = new JButton("Generate Report");
        btnGenerate.setBounds(220, 52, 150, 30);
        panel.add(btnGenerate);
        
        // Export button
        JButton btnExport = new JButton("Export to File");
        btnExport.setBounds(380, 52, 150, 30);
        panel.add(btnExport);

        JButton exitBtn = new JButton("EXIT");
        exitBtn.setBounds(540, 52, 150, 30);
        panel.add(exitBtn);

        // Action listeners
        exitBtn.addActionListener(e -> {
            frame.dispose();
            Management.main(null); // Logic to return to ChooseStore
        });
        btnGenerate.addActionListener(new GenerateReportAction());
        btnExport.addActionListener(e -> exportReportToFile());
    }

    // Action class to generate report
    private class GenerateReportAction implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String selectedReport = (String) reportSelection.getSelectedItem();
            switch (selectedReport) {
                case "Stock Report":
                    generateStockReport();
                    break;
                case "Items by Manufacturer":
                    generateItemsByManufacturerReport();
                    break;
                case "Customer Receipts":
                    generateCustomerReceiptsReport();
                    break;
                case "Most Popular Products by Quantity":
                    generatePopularProductsByQuantity();
                    break;
                case "Most Popular Products by Revenue":
                    generatePopularProductsByRevenue();
                    break;
                case "Product Report":
                    generateProductReport();
                    break;
                case "Customer List": // New case for customer list
                    generateCustomerListReport();
                    break;
                default:
                    reportArea.setText("Please select a valid report.");
            }
        }
    }

    // Method to generate Product Report
    private void generateProductReport() {
        reportArea.setText(""); // Clear previous report

        try (BufferedReader reader = new BufferedReader(new FileReader("products.txt"))) {
            List<String[]> products = new ArrayList<>();
            String line;

            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                String storeId = details[0];
                String productId = details[1];
                String productName = details[2];
                String manufacturer = details[3];
                double price = Double.parseDouble(details[4]);
                int quantity = Integer.parseInt(details[5]);
                boolean isFoodProduct = details[6].equalsIgnoreCase("true"); // Adjusted line

                double totalValue = price * quantity;

                products.add(new String[]{storeId, productId, productName, manufacturer, String.valueOf(price), String.valueOf(quantity), String.valueOf(totalValue), isFoodProduct ? "Food" : "Not Food"});
            }

            // Sort products by name
            products.sort(Comparator.comparing(o -> o[2]));

            reportArea.append("Product Report\n");
            reportArea.append("---------------------------------------------------------------\n");
            reportArea.append("Product ID\tName\tManufacturer\tPrice\tQuantity\tTotal Value\tFood Product\n");
            reportArea.append("---------------------------------------------------------------\n");

            double grandTotalValue = 0;
            int uniqueProducts = products.size();

            for (String[] product : products) {
                reportArea.append(String.format("%s\t%s\t%s\t$%.2f\t%d\t$%.2f\t%s\n",
                        product[1], product[2], product[3], Double.parseDouble(product[4]), Integer.parseInt(product[5]),
                        Double.parseDouble(product[6]), product[7]));
                grandTotalValue += Double.parseDouble(product[6]);
            }

            reportArea.append("\nTotal Unique Products: " + uniqueProducts);
            reportArea.append("\nTotal Value of Products: $" + String.format("%.2f", grandTotalValue));

        } catch (IOException ex) {
            ex.printStackTrace();
            reportArea.setText("Error loading product data.");
        } catch (NumberFormatException ex) {
            reportArea.setText("Error in number format. Please check the product data.");
        }
    }

    // Method to generate Stock Report from products.txt
    private void generateStockReport() {
        reportArea.setText(""); // Clear previous report

        try (BufferedReader reader = new BufferedReader(new FileReader("products.txt"))) {
            ArrayList<String> products = new ArrayList<>();
            String line;
            double totalValue = 0;
            int uniqueProducts = 0;

            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                String storeId = details[0];
                String productId = details[1];
                String productName = details[2];
                String manufacturer = details[3];
                double price = Double.parseDouble(details[4]);
                int quantity = Integer.parseInt(details[5]);
                boolean isFoodProduct = details[6].equalsIgnoreCase("Yes");

                double productTotalValue = price * quantity;
                totalValue += productTotalValue;
                uniqueProducts++;

                products.add(String.format("%s\t%s\t%s\t%s\t$%.2f\t%d\t$%.2f\t%s",
                        storeId, productId, productName, manufacturer, price, quantity, productTotalValue,
                        isFoodProduct ? "Food" : "Not Food"));
            }

            products.sort(Comparator.comparing((String product) -> product.split("\t")[1]));

            reportArea.append("Stock Report\n");
            reportArea.append("Store ID\tProduct ID\tName\tManufacturer\tPrice\tQuantity\tTotal Value\tFood Product\n");
            reportArea.append("---------------------------------------------------------------\n");

            for (String product : products) {
                reportArea.append(product + "\n");
            }

            reportArea.append("\nTotal Unique Products: " + uniqueProducts);
            reportArea.append("\nTotal Value of Products: $" + String.format("%.2f", totalValue));

        } catch (IOException ex) {
            ex.printStackTrace();
            reportArea.setText("Error loading stock data.");
        }
    }

    // Method to generate Items by Manufacturer report
    private void generateItemsByManufacturerReport() {
        reportArea.setText(""); // Clear previous report

        try (BufferedReader reader = new BufferedReader(new FileReader("products.txt"))) {
            Map<String, List<String>> manufacturerMap = new HashMap<>();
            String line;

            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                String productId = details[1];
                String productName = details[2];
                String manufacturer = details[3];

                manufacturerMap.computeIfAbsent(manufacturer, k -> new ArrayList<>())
                               .add(String.format("%s\t%s", productId, productName));
            }

            List<String> sortedManufacturers = new ArrayList<>(manufacturerMap.keySet());
            Collections.sort(sortedManufacturers);

            reportArea.append("Items by Manufacturer Report\n");
            reportArea.append("---------------------------------------------------------------\n");

            for (String manufacturer : sortedManufacturers) {
                reportArea.append("\nManufacturer: " + manufacturer + "\n");
                reportArea.append("---------------------------------------------------------------\n");
                for (String product : manufacturerMap.get(manufacturer)) {
                    reportArea.append(product + "\n");
                }
            }

        } catch (IOException ex) {
            ex.printStackTrace();
            reportArea.setText("Error loading stock data.");
        }
    }

    private void generateCustomerReceiptsReport() {
        reportArea.setText(""); // Clear previous report

        try (BufferedReader reader = new BufferedReader(new FileReader("orders.txt"))) {
            String line;
            StringBuilder receiptBuilder = new StringBuilder();

            reportArea.append("Customer Receipts Report\n");
            reportArea.append("---------------------------------------------------------------\n");

            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Order ID:")) {
                    receiptBuilder.append(line).append("\n");
                } else if (line.startsWith("Customer ID:")) {
                    receiptBuilder.append(line).append("\n");
                } else if (line.startsWith("Items:")) {
                    receiptBuilder.append(line).append("\n");
                    while ((line = reader.readLine()) != null && !line.startsWith("Total Cost:")) {
                        receiptBuilder.append(line).append("\n");
                    }
                    if (line != null) {
                        receiptBuilder.append(line).append("\n");
                    }
                    receiptBuilder.append("=================================\n");
                }
            }

            reportArea.append(receiptBuilder.toString());

        } catch (IOException ex) {
            ex.printStackTrace();
            reportArea.setText("Error loading customer receipts.");
        }
    }

    private void generatePopularProductsByQuantity() {
        reportArea.setText(""); // Clear previous report
        Map<String, Integer> productQuantityMap = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Items:")) {
                    while ((line = reader.readLine()) != null && !line.startsWith("Total Cost:")) {
                        String[] itemParts = line.split(" x ");
                        if (itemParts.length == 2) {
                            String productName = itemParts[0].trim();
                            int quantity = Integer.parseInt(itemParts[1].trim());
                            productQuantityMap.put(productName, productQuantityMap.getOrDefault(productName, 0) + quantity);
                        }
                    }
                }
            }

            var sortedProducts = productQuantityMap.entrySet()
                .stream()
                .sorted((a, b) -> b.getValue().compareTo(a.getValue()))
                .collect(Collectors.toList());

            reportArea.append("Most Popular Products by Quantity\n");
            reportArea.append("Product Name\tTotal Quantity Sold\n");
            reportArea.append("---------------------------------------\n");

            for (var entry : sortedProducts) {
                reportArea.append(String.format("%s\t\t%d\n", entry.getKey(), entry.getValue()));
            }

        } catch (IOException ex) {
            ex.printStackTrace();
            reportArea.setText("Error loading order data.");
        }
    }

    private void generatePopularProductsByRevenue() {
        reportArea.setText(""); // Clear previous report
        Map<String, Double> productRevenueMap = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Items:")) {
                    while ((line = reader.readLine()) != null && !line.startsWith("Total Cost:")) {
                        String[] itemParts = line.split(" x ");
                        if (itemParts.length == 2) {
                            String productName = itemParts[0].trim();
                            int quantity = Integer.parseInt(itemParts[1].trim());
                            double price = loadProductPrice(productName);
                            productRevenueMap.put(productName, productRevenueMap.getOrDefault(productName, 0.0) + (quantity * price));
                        }
                    }
                }
            }

            var sortedProducts = productRevenueMap.entrySet()
                .stream()
                .sorted((a, b) -> b.getValue().compareTo(a.getValue()))
                .collect(Collectors.toList());

            reportArea.append("Most Popular Products by Revenue\n");
            reportArea.append("Product Name\tTotal Revenue\n");
            reportArea.append("---------------------------------------\n");

            for (var entry : sortedProducts) {
                reportArea.append(String.format("%s\t\t$%.2f\n", entry.getKey(), entry.getValue()));
            }

        } catch (IOException ex) {
            ex.printStackTrace();
            reportArea.setText("Error loading order data.");
        }
    }

    private double loadProductPrice(String productName) {
        try (BufferedReader reader = new BufferedReader(new FileReader("products.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                if (details[2].equals(productName)) {
                    return Double.parseDouble(details[4]);
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return 0.0;
    }

    private void exportReportToFile() {
        String reportText = reportArea.getText();
        if (reportText.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "No report generated to export.");
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("Report.txt"))) {
            writer.write(reportText);
            JOptionPane.showMessageDialog(frame, "Report exported to Report.txt.");
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error exporting report.");
        }
    }

    // Method to generate Customer List Report
    private void generateCustomerListReport() {
        reportArea.setText(""); // Clear previous report

        try (BufferedReader reader = new BufferedReader(new FileReader("customers.txt"))) {
            List<Customer> customers = new ArrayList<>();
            String line;

            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                if (details.length < 3) {
                    reportArea.append("Error: Insufficient data in line: " + line + "\n");
                    continue; // Skip this line if it doesn't have enough data
                }

                String lastName = details[0];
                String firstName = details[1];
              String customerId = details[2];

                customers.add(new Customer(lastName, firstName, customerId));
            }

            // Sort customers by last name, then first name, then customer ID
            customers.sort(Comparator.comparing(Customer::getLastName)
                                      .thenComparing(Customer::getFirstName)
                                      .thenComparing(Customer::getCustomerID));

            reportArea.append("Customer List Report\n");
            reportArea.append("---------------------------------------------------------------\n");
            reportArea.append("Last Name\tFirst Name\tCustomer ID\n");
            reportArea.append("---------------------------------------------------------------\n");

            for (Customer customer : customers) {
                reportArea.append(String.format("%s\t%s\t%s\n", customer.getLastName(), customer.getFirstName(), customer.getCustomerID()));
            }

            reportArea.append("\nTotal Number of Customers: " + customers.size());

        } catch (IOException ex) {
            ex.printStackTrace();
            reportArea.setText("Error loading customer data.");
        } catch (NumberFormatException ex) {
            reportArea.setText("Error in customer ID format. Please check the customer data.");
        }
    }
}