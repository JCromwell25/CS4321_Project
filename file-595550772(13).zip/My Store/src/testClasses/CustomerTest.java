package testClasses;

import sms.Customer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {

    private static final String TEST_CUSTOMER_FILE = "customers_test.txt";

    @BeforeEach
    void setUp() {
        // Set the customer file to the test file
        Customer.setCustomerFile(TEST_CUSTOMER_FILE);
        
        // Ensure customers_test.txt is empty before each test
        try {
            File testFile = new File(TEST_CUSTOMER_FILE);
            if (testFile.exists()) {
                testFile.delete();
            }
            testFile.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @AfterEach
    void tearDown() {
        // Clean up the test file after each test
        new File(TEST_CUSTOMER_FILE).delete();
    }

    @Test
    void testGenerateCustomerID() {
        String customerID = Customer.generateCustomerID();
        assertNotNull(customerID, "Customer ID should not be null");
        assertEquals(4, customerID.length(), "Customer ID should be 4 digits long");
    }

    @Test
    void testSaveCustomerToFile() {
        Customer customer = new Customer("0001", "John", "Doe");
        assertTrue(Customer.saveCustomerToFile(customer), "Customer should be saved successfully");

        // Verify if the customer is saved correctly
        String expectedLine = "0001,John,Doe";
        try (Scanner scanner = new Scanner(new File(TEST_CUSTOMER_FILE))) {
            assertTrue(scanner.hasNextLine(), "File should have at least one line");
            assertEquals(expectedLine, scanner.nextLine(), "Saved customer data should match");
        } catch (IOException e) {
            e.printStackTrace();
            fail("Exception during file reading");
        }
    }

    @Test
    void testIsCustomerIDExists() {
        Customer customer = new Customer("0002", "Jane", "Doe");
        Customer.saveCustomerToFile(customer);

        assertTrue(Customer.isCustomerIDExists("0002"), "Customer ID should exist");
        assertFalse(Customer.isCustomerIDExists("0003"), "Customer ID should not exist");
    }

    @Test
    void testVerifyCustomer() {
        Customer customer = new Customer("0004", "Alice", "Smith");
        Customer.saveCustomerToFile(customer);

        assertTrue(Customer.verifyCustomer("0004", "Alice", "Smith"), "Customer should be verified");
        assertFalse(Customer.verifyCustomer("0004", "Alice", "Doe"), "Customer verification should fail for incorrect last name");
        assertFalse(Customer.verifyCustomer("0005", "Bob", "Smith"), "Customer verification should fail for non-existing customer ID");
    }
}