package sms;

import java.io.*;
import java.util.Random;
import java.util.Scanner;

public class Customer {
    private static String CUSTOMER_FILE = "customers.txt"; // Default file
    private String customerID;
    private String firstName;
    private String lastName;

    public Customer(String customerID, String firstName, String lastName) {
        this.customerID = customerID;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getCustomerID() {
        return customerID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public static void setCustomerFile(String filePath) {
        CUSTOMER_FILE = filePath; // Set a custom file for testing
    }

    public static String generateCustomerID() {
        Random rand = new Random();
        String customerID;
        do {
            customerID = String.format("%04d", rand.nextInt(10000)); // Generate 4-digit ID
        } while (isCustomerIDExists(customerID));
        return customerID;
    }

    public static boolean saveCustomerToFile(Customer customer) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CUSTOMER_FILE, true))) {
            writer.write(customer.getCustomerID() + "," + customer.getFirstName() + "," + customer.getLastName());
            writer.newLine();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean isCustomerIDExists(String customerID) {
        try (Scanner scanner = new Scanner(new File(CUSTOMER_FILE))) {
            while (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                if (data.length > 0 && data[0].equals(customerID)) {
                    return true;
                }
            }
        } catch (FileNotFoundException e) {
            // File not found; assume no customers exist yet
        }
        return false;
    }

    public static boolean verifyCustomer(String customerID, String firstName, String lastName) {
        try (Scanner scanner = new Scanner(new File(CUSTOMER_FILE))) {
            while (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                if (data.length == 3 && data[0].equals(customerID) && data[1].equalsIgnoreCase(firstName) && data[2].equalsIgnoreCase(lastName)) {
                    return true;
                }
            }
        } catch (FileNotFoundException e) {
            // File not found; return false
        }
        return false;
    }
}