package sms;

import java.awt.EventQueue;
import java.awt.Color;
import java.awt.Font;

import javax.swing.*;

public class Login {

    private JFrame frmLoginWindow;
    private JTextField customerIDField;
    private JTextField firstNameField;
    private JTextField lastNameField;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Login window = new Login();
                window.frmLoginWindow.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the application.
     */
    public Login() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frmLoginWindow = new JFrame();
        frmLoginWindow.setResizable(false);
        frmLoginWindow.setTitle("LOGIN WINDOW ");
        frmLoginWindow.setBounds(100, 100, 600, 400);
        frmLoginWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmLoginWindow.getContentPane().setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 584, 361);
        frmLoginWindow.getContentPane().add(panel);
        panel.setLayout(null);

        JLabel header = new JLabel("STORE MANAGEMENT SYSTEM");
        header.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        header.setBackground(Color.LIGHT_GRAY);
        header.setBounds(138, 11, 349, 36);
        panel.add(header);

        JLabel customerIDLabel = new JLabel("CUSTOMER ID");
        customerIDLabel.setBounds(38, 71, 160, 45);
        panel.add(customerIDLabel);

        customerIDField = new JTextField();
        customerIDField.setColumns(10);
        customerIDField.setBounds(218, 71, 247, 45);
        panel.add(customerIDField);

        JLabel firstNameLabel = new JLabel("FIRST NAME");
        firstNameLabel.setBounds(38, 147, 160, 45);
        panel.add(firstNameLabel);

        firstNameField = new JTextField();
        firstNameField.setBounds(218, 147, 247, 45);
        panel.add(firstNameField);
        firstNameField.setColumns(10);

        JLabel lastNameLabel = new JLabel("LAST NAME");
        lastNameLabel.setBounds(38, 222, 160, 45);
        panel.add(lastNameLabel);

        lastNameField = new JTextField();
        lastNameField.setColumns(10);
        lastNameField.setBounds(218, 222, 247, 45);
        panel.add(lastNameField);

        JButton loginBtn = new JButton("LOGIN");
        loginBtn.setBounds(93, 298, 123, 36);
        panel.add(loginBtn);
        loginBtn.addActionListener(e -> login());

        JButton registerBtn = new JButton("REGISTER");
        registerBtn.setBounds(342, 298, 123, 36);
        panel.add(registerBtn);
        registerBtn.addActionListener(e -> registerCustomer());

        JButton btnManage = new JButton("MANAGE");
        btnManage.setBounds(477, 20, 97, 27);
        panel.add(btnManage);
        btnManage.addActionListener(e -> {
            frmLoginWindow.dispose();
            Management.main(null); // Logic to return to ChooseStore
        });
    }

    // Method to register a new customer
    private void registerCustomer() {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();

        if (firstName.isEmpty() || lastName.isEmpty()) {
            JOptionPane.showMessageDialog(frmLoginWindow, "Please enter both first and last names.");
            return;
        }

        String customerID = Customer.generateCustomerID();
        Customer customer = new Customer(customerID, firstName, lastName);
        if (Customer.saveCustomerToFile(customer)) {
            JOptionPane.showMessageDialog(frmLoginWindow, "Registration successful! Your ID is " + customerID);
            customerIDField.setText(customerID);
        } else {
            JOptionPane.showMessageDialog(frmLoginWindow, "Registration failed. Try again.");
        }
    }

    // Method to login with customer ID, first name, and last name
    private void login() {
        String customerID = customerIDField.getText().trim();
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();

        if (customerID.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
            JOptionPane.showMessageDialog(frmLoginWindow, "Please enter your ID, first name, and last name.");
            return;
        }

        if (Customer.verifyCustomer(customerID, firstName, lastName)) {
            JOptionPane.showMessageDialog(frmLoginWindow, "Login successful!");
            frmLoginWindow.dispose();
            ChooseStore.main(null);
        } else {
            JOptionPane.showMessageDialog(frmLoginWindow, "Login failed. Check your details.");
        }
    }
}