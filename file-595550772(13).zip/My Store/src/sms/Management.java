package sms;

import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;

public class Management {

    private JFrame frame;
    private JTextField sIdField;
    private JTextField sNameField;
    private JTextField pIdField;
    private JTextField pNameField;
    private JTextField manufacturerField;
    private JTextField priceField;
    private JTextField quantityField;
    private JTextArea textArea;
    private JComboBox<String> storeIdCombo;
    private static final String STORE_FILE = "store.txt";
    private static final String PRODUCTS_FILE = "products.txt";
    private JTextArea itemsArea;
    private JCheckBox isFoodBox;
    private JTextField newPriceField; // New field for entering the new price

    // Sets to track uploaded files
    private Set<String> uploadedStoreFiles = new HashSet<>();
    private Set<String> uploadedProductFiles = new HashSet<>();

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Management window = new Management();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Management() {
        initialize();
        loadStoresFromFile(STORE_FILE); // Load stores data from the file
        loadProductsData(); // Load products data
    }

    private void initialize() {
        frame = new JFrame();
        frame.setResizable(false);
        frame.setBounds(100, 100, 950, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        
        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 934, 461);
        frame.getContentPane().add(panel);
        panel.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("MANAGEMENT WINDOW");
        lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setBounds(315, 11, 264, 28);
        panel.add(lblNewLabel);
        
        JButton addStoreBtn = new JButton("ADD STORE");
        addStoreBtn.setBounds(21, 164, 179, 38);
        panel.add(addStoreBtn);
        addStoreBtn.addActionListener(e -> addStore());
        
        JButton uploadFileBtn = new JButton("UPLOAD STORE FILE");
        uploadFileBtn.setBounds(210, 164, 179, 38);
        panel.add(uploadFileBtn);
        uploadFileBtn.addActionListener(e -> uploadStoreFile());

        JButton uploadProductsFileBtn = new JButton("UPLOAD PRODUCTS");
        uploadProductsFileBtn.setBounds(765, 69, 167, 38);
        panel.add(uploadProductsFileBtn);
        uploadProductsFileBtn.addActionListener(e -> uploadProductsFile());

        textArea = new JTextArea();
        textArea.setBackground(Color.LIGHT_GRAY);
        textArea.setBounds(10, 226, 288, 224);
        panel.add(textArea);
        
        JLabel lblNewLabel_1 = new JLabel("STORES");
        lblNewLabel_1.setBounds(81, 213, 60, 14);
        panel.add(lblNewLabel_1);
        
        JLabel lblNewLabel_2 = new JLabel("STORE ID");
        lblNewLabel_2.setBounds(10, 62, 60, 14);
        panel.add(lblNewLabel_2);
        
        sIdField = new JTextField();
        sIdField.setBounds(88, 59, 109, 28);
        panel.add(sIdField);
        sIdField.setColumns(10);
        
        JLabel lblNewLabel_2_1 = new JLabel("STORE NAME");
        lblNewLabel_2_1.setBounds(10, 109, 77, 14);
        panel.add(lblNewLabel_2_1);
        
        sNameField = new JTextField();
        sNameField.setColumns(10);
        sNameField.setBounds(88, 106, 109, 28);
        panel.add(sNameField);
        
        JPanel panel_2 = new JPanel();
        panel_2.setBorder(new LineBorder(new Color(0, 0, 0)));
        panel_2.setBounds(403, 62, 352, 388);
        panel.add(panel_2);
        panel_2.setLayout(null);
        
        JLabel lblNewLabel_3 = new JLabel("STORE ID");
        lblNewLabel_3.setBounds(10, 11, 75, 14);
        panel_2.add(lblNewLabel_3);
        
        storeIdCombo = new JComboBox<>();
        storeIdCombo.setBounds(78, 7, 94, 22);
        panel_2.add(storeIdCombo);
        
        JLabel lblNewLabel_4 = new JLabel("PRODUCT ID");
        lblNewLabel_4.setBounds(182, 10, 75, 25);
        panel_2.add(lblNewLabel_4);
        
        pIdField = new JTextField();
        pIdField.setBounds(260, 7, 84, 28);
        panel_2.add(pIdField);
        pIdField.setColumns(10);
        
        JLabel lblNewLabel_5 = new JLabel("PROD NAME");
        lblNewLabel_5.setBounds(182, 53, 69, 25);
        panel_2.add(lblNewLabel_5);
        
        pNameField = new JTextField();
        pNameField.setBounds(256, 50, 86, 28);
        panel_2.add(pNameField);
        pNameField.setColumns(10);
        
        JLabel lblNewLabel_6 = new JLabel("MANUFACTURER");
        lblNewLabel_6.setBounds(10, 97, 94, 14);
        panel_2.add(lblNewLabel_6);
        
        manufacturerField = new JTextField();
        manufacturerField.setColumns(10);
        manufacturerField.setBounds(122, 89, 220, 28);
        panel_2.add(manufacturerField);
        
        JLabel lblNewLabel_4_1 = new JLabel("PRICE");
        lblNewLabel_4_1.setBounds(10, 135, 69, 26);
        panel_2.add(lblNewLabel_4_1);
        
        priceField = new JTextField();
        priceField.setColumns(10);
        priceField.setBounds(78, 132, 94, 29);
        panel_2.add(priceField);
        
        JLabel lblNewLabel_4_1_1 = new JLabel("QUANTITY");
        lblNewLabel_4_1_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_4_1_1.setBounds(182, 131, 69, 26);
        panel_2.add(lblNewLabel_4_1_1);
        
        quantityField = new JTextField();
        quantityField.setColumns(10);
        quantityField.setBounds(250, 128, 94, 29);
        panel_2.add(quantityField);
        
        JButton btnAdd = new JButton("ADD PRODUCT");
        btnAdd.setBounds(10, 186, 133, 34);
        panel_2.add(btnAdd);
        btnAdd.addActionListener(e -> addProduct());
        
        JButton btnAddQuantity = new JButton("ADD QUANTITY");
        btnAddQuantity.setBounds(209, 186, 133, 34);
        panel_2.add(btnAddQuantity);
        btnAddQuantity.addActionListener(e -> addQuantity());
        
        JButton btnRemove = new JButton("REMOVE");
        btnRemove.setBounds(122, 233, 94, 34);
        panel_2.add(btnRemove);
        btnRemove.addActionListener(e -> removeProduct());
        
        isFoodBox = new JCheckBox("IS FOOD");
        isFoodBox.setBackground(Color.LIGHT_GRAY);
        isFoodBox.setHorizontalAlignment(SwingConstants.CENTER);
        isFoodBox.setBounds(10, 54, 162, 23);
        panel_2.add(isFoodBox);
        
        itemsArea = new JTextArea();
        itemsArea.setBounds(10, 278, 332, 106);
        panel_2.add(itemsArea);
        itemsArea.setBackground(Color.LIGHT_GRAY);

        JButton exitBtn = new JButton("EXIT");
        exitBtn.setBounds(774, 400, 120, 38);
        panel.add(exitBtn);
        
        JButton genReportBtn = new JButton("GENERATE REPORTS");
        genReportBtn.setBounds(765, 130, 159, 38);
        panel.add(genReportBtn);
        
        // New button for changing price
        JButton changePriceBtn = new JButton("CHANGE PRICE");
        changePriceBtn.setBounds(774, 329, 133, 34);
        panel.add(changePriceBtn);
        
        // New field for entering new price
        newPriceField = new JTextField();
        newPriceField.setBounds(774, 290, 133, 28);
        panel.add(newPriceField);
        changePriceBtn.addActionListener(e -> changeProductPrice());
        
        exitBtn.addActionListener(e -> {
            frame.dispose();
            Login.main(null);
        });
        
        genReportBtn.addActionListener(e -> {
            frame.dispose();
            ReportGenerator.main(null);
        });
    }

    private void addStore() {
        String storeID = sIdField.getText().trim();
        String storeName = sNameField.getText().trim();

        if (storeID.isEmpty() || storeName.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Store ID and Name cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Store newStore = new Store(storeID, storeName);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(STORE_FILE, true))) {
            writer.write(newStore.toString());
            writer.newLine();
            loadStoresFromFile(STORE_FILE); // Reload store data
            JOptionPane.showMessageDialog(frame, "Store added successfully.");
            sIdField.setText("");
            sNameField.setText("");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error adding store.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void uploadStoreFile() {
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(frame);
        
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            
            // Check if the file has already been uploaded
            if (uploadedStoreFiles.contains(selectedFile.getName())) {
                JOptionPane.showMessageDialog(frame, "This store file has already been uploaded.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try (BufferedReader reader = new BufferedReader(new FileReader(selectedFile))) {
                String line;
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(STORE_FILE, true))) {
                    while ((line = reader.readLine()) != null) {
                        writer.write(line);
                        writer.newLine();
                    }
                }
                uploadedStoreFiles.add(selectedFile.getName()); // Mark this file as uploaded
                JOptionPane.showMessageDialog(frame, "Stores uploaded successfully.");
                loadStoresFromFile(STORE_FILE); // Reload store data
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Error uploading stores from file.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void uploadProductsFile() {
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(frame);
        
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            
            // Check if the file has already been uploaded
            if (uploadedProductFiles.contains(selectedFile.getName())) {
                JOptionPane.showMessageDialog(frame, "This product file has already been uploaded.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try (BufferedReader reader = new BufferedReader(new FileReader(selectedFile))) {
                String line;
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(PRODUCTS_FILE, true))) {
                    while ((line = reader.readLine()) != null) {
                        writer.write(line);
                        writer.newLine();
                    }
                }
                uploadedProductFiles.add(selectedFile.getName()); // Mark this file as uploaded
                JOptionPane.showMessageDialog(frame, "Products uploaded successfully.");
                loadProductsData(); // Reload product data
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Error uploading products from file.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void loadStoresFromFile(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            textArea.setText(""); // Clear existing text
            storeIdCombo.removeAllItems(); // Clear existing items
            while ((line = reader.readLine()) != null) {
                Store store = new Store(line.split(",")[0], line.split(",")[1]);
                textArea.append("Store ID: " + store.getId() + " | Store Name: " + store.getName() + "\n");
                storeIdCombo.addItem(store.getId()); // Add the store ID to the combo box
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error loading stores from file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addProduct() {
        String storeID = (String) storeIdCombo.getSelectedItem();
        String productID = pIdField.getText().trim();
        String productName = pNameField.getText().trim();
        String manufacturer = manufacturerField.getText().trim();
        String price = priceField.getText().trim();
        String quantity = quantityField.getText().trim();
        boolean isFood = isFoodBox.isSelected();

        if (productID.isEmpty() || productName.isEmpty() || manufacturer.isEmpty() || price.isEmpty() || quantity.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "All fields must be filled.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Product newProduct = new Product(storeID, productID, productName, manufacturer, Double.parseDouble(price), Integer.parseInt(quantity), isFood);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PRODUCTS_FILE, true))) {
            writer.write(newProduct.toString());
            writer.newLine();
            JOptionPane.showMessageDialog(frame, "Product added successfully.");
            loadProductsData(); // Reload product data
            clearFields();
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error adding product.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        pIdField.setText("");
        pNameField.setText("");
        manufacturerField.setText("");
        priceField.setText("");
        quantityField.setText("");
        newPriceField.setText(""); // Clear the new price field
    }

    private void loadProductsData() {
        itemsArea.setText("");
        try (BufferedReader reader = new BufferedReader(new FileReader(PRODUCTS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Trim the line to avoid issues with whitespace
                line = line.trim();
                // Check if the line is empty
                if (line.isEmpty()) {
                    continue; // Skip empty lines
                }
                String[] productDetails = line.split(",");
                // Check if productDetails has the expected number of elements
                if (productDetails.length < 7) {
                    JOptionPane.showMessageDialog(frame, "Invalid product data format: " + line, "Error", JOptionPane.ERROR_MESSAGE);
                    continue; // Skip this line
                }
                // Append valid product details to itemsArea
                itemsArea.append("Store ID: " + productDetails[0] + 
                                 " | Product ID: " + productDetails[1] + 
                                 " | Product Name: " + productDetails[2] + 
                                 " | Manufacturer: " + productDetails[3] + 
                                 " | Price: " + productDetails[4] + 
                                 " | Quantity: " + productDetails[5] + 
                                 " | Is Food: " + productDetails[6] + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error loading products.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void removeProduct() {
        String productID = pIdField.getText().trim();
        String storeID = (String) storeIdCombo.getSelectedItem();
        
        if (productID.isEmpty() || storeID == null) {
            JOptionPane.showMessageDialog(frame, "Please select a store and enter a product ID.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            BufferedReader reader = new BufferedReader(new FileReader(PRODUCTS_FILE));
            StringBuilder updatedProducts = new StringBuilder();
            String line;
            boolean productFound = false;

            while ((line = reader.readLine()) != null) {
                String[] productDetails = line.split(",");
                if (productDetails[0].equals(storeID) && productDetails[1].equals(productID)) {
                    productFound = true;
                    continue; // Skip this product
                }
                updatedProducts.append(line).append("\n");
            }

            reader.close();

            // If the product was found, write the updated list back to the file
            if (productFound) {
                BufferedWriter writer = new BufferedWriter(new FileWriter(PRODUCTS_FILE));
                writer.write(updatedProducts.toString());
                writer.close();
                JOptionPane.showMessageDialog(frame, "Product removed successfully.");
                loadProductsData(); // Reload product data
            } else {
                JOptionPane.showMessageDialog(frame, "Product not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error removing product.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addQuantity() {
        String productID = pIdField.getText().trim();
        String storeID = (String) storeIdCombo.getSelectedItem();
        String quantity = quantityField.getText().trim();

        if (productID.isEmpty() || storeID == null || quantity.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please select a store, enter a product ID, and specify the quantity.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            BufferedReader reader = new BufferedReader(new FileReader(PRODUCTS_FILE));
            StringBuilder updatedProducts = new StringBuilder();
            String line;
            boolean productFound = false;

            while ((line = reader.readLine()) != null) {
                String[] productDetails = line.split(",");
                if (productDetails[0].equals(storeID) && productDetails[1].equals(productID)) {
                    int currentQuantity = Integer.parseInt(productDetails[5]);
                    int additionalQuantity = Integer.parseInt(quantity);
                    productDetails[5] = String.valueOf(currentQuantity + additionalQuantity); // Update quantity
                    productFound = true;
                }
                updatedProducts.append(String.join(",", productDetails)).append("\n");
            }

            reader.close();

            if (productFound) {
                BufferedWriter writer = new BufferedWriter(new FileWriter(PRODUCTS_FILE));
                writer.write(updatedProducts.toString());
                writer.close();
                JOptionPane.showMessageDialog(frame, "Quantity added successfully.");
                loadProductsData(); // Reload product data
            } else {
                JOptionPane.showMessageDialog(frame, "Product not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error adding quantity.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void changeProductPrice() {
        String productID = pIdField.getText().trim();
        String storeID = (String) storeIdCombo.getSelectedItem();
        String newPrice = newPriceField.getText().trim();

        if (productID.isEmpty() || storeID == null || newPrice.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please select a store, enter a product ID, and specify the new price.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            BufferedReader reader = new BufferedReader(new FileReader(PRODUCTS_FILE));
            StringBuilder updatedProducts = new StringBuilder();
            String line;
            boolean productFound = false;

            while ((line = reader.readLine()) != null) {
                String[] productDetails = line.split(",");
                if (productDetails[0].equals(storeID) && productDetails[1].equals(productID)) {
                    // Update the price
                    productDetails[4] = newPrice; // Assuming price is at index 4
                    productFound = true;
                }
                updatedProducts.append(String.join(",", productDetails)).append("\n");
            }

            reader.close();

            if (productFound) {
                BufferedWriter writer = new BufferedWriter(new FileWriter(PRODUCTS_FILE));
                writer.write(updatedProducts.toString());
                writer.close();
                JOptionPane.showMessageDialog(frame, "Price updated successfully.");
                loadProductsData(); // Reload product data
            } else {
                JOptionPane.showMessageDialog(frame, "Product not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error updating price.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}